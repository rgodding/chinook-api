<?php
require_once __DIR__ . '/core/constants.php';
require_once __DIR__ . '/core/apiResponse.php';
require_once __DIR__ . '/utils/logger.php';
require_once __DIR__ . '/utils/urlFunctions.php';
define('BASE_PATH', __DIR__);
define('API_NAME', 'chinook-api');
?>