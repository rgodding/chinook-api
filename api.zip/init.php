<?php
require_once __DIR__ . '/core/Constants.php';
require_once __DIR__ . '/core/ApiResponse.php';
require_once __DIR__ . '/utils/logger.php';
require_once __DIR__ . '/utils/urlFunctions.php';
define('BASE_PATH', __DIR__);
define('API_NAME', 'chinook-api');
?>