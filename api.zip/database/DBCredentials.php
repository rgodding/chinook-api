<?php

class DBCredentials
{
    protected string $host = 'localhost';
    protected string $dbname = 'chinook_autoincrement';
    protected string $user = 'root';
    protected string $password = 'Skejs123';
}
/*
DB_HOST=sql111.infinityfree.com
DB_NAME=if0_39044140_chinookkea2025
DB_USER=if0_39044140
DB_PASSWORD=zApp3PJFwqMDxu
*/